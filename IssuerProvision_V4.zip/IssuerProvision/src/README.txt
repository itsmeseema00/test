This project contains the sample code for issuer provisioning that encrypts data on the issuer side.
It generates the encrypted data, the ephemeral public key and the public key hash of the Apple server public key.
It uses the test vector to verify the code.

The sample code does not verify the Apple server public key. Issuers need to validate the Apple server certificate before using it.

To build the sample:

$ mvn clean install

To test the sample:

$ mvn test
