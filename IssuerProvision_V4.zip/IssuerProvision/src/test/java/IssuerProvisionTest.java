import junit.framework.TestCase;
import org.bouncycastle.util.encoders.Hex;
import org.junit.Assert;

import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;

/**
 * Created by liliang on 7/19/16.
 * CopyRight Apple Inc.
 * See LICENSE.txt for this sample’s licensing information
 */
public class IssuerProvisionTest extends TestCase {

    //this test case use the input in the test vector to test encryption code
    public void testEncryptData() throws Exception {

        //from the test vector
        String ephemeralPublicKey="0401e8adc2bb6674fc4fe469e8a599bcd25647073ba535374b9d4f473a8c8917a1057b00c0aa69e912f842e0d3fd9af225d78676caaede5204dfefd45dc2ea4d5b";

        //from the test vector
        String ephemeralPrivateKey="a040aab7f0111b0cf1e470f16944b04ebeaaebd7165a622da127d7685fcdb714";

        ECPublicKey ecPublicKey= CryptoUtils.hex2ECDHPublicKey(ephemeralPublicKey.substring(2,66),ephemeralPublicKey.substring(66));

        ECPrivateKey ecPrivateKey= CryptoUtils.hexToECDHCPrivateKey(ephemeralPrivateKey);

        //from test vector
        String data="{\"nonce\":\"9c023092\",\"nonceSignature\":\"4082f883ae62d0700c283e225ee9d286713ef74456ba1f07376cf17d71bf0be013f926d486619394060ced56030f41f84df916eaab5504e456a8530dc9c821f6ed3e3af62b5d8f3e4a22ca2018670fee4e\",\"name\":\"Tester Bob\",\"expiration\":\"12\\/15\",\"primaryAccountNumber\":\"9876543210\"}";
        byte[] dataBytes=data.getBytes("UTF-8");

        byte[] encryptedData=IssuerProvision.encryptData(dataBytes,ecPublicKey,ecPrivateKey);

        String encryptedDataHex= Hex.toHexString(encryptedData);

        String encryptedDataOnVector="6850faf186789cbcfd5d17ee3c5f7d6fb5254c3cab3a9ed03e38a12c5f244d60160a8613c0faa090553dd4f330e6f561a1ccdb1277285fd111947830a37845e56c3012643c735eb20213ece170b0e6dc84de3f76c93ee9c171964ee4b7627c7650fa7c3b7f1689bb0c51f6253c1679b14eb3f014930e155170bc853577daf2fee75df308252d9a6908c04d956c986af21df172084b9367b8ccbaebb94cc686f242856c525ba72049b121958875a4faf6d48db1518d98430cfa98182f081e5c93e6950f0f18eea919a03668c3b7b0cbd0baf706c3d4552bdeb78d6a16d80d65f3787f57a1a65b20322dc0bcadcab52736c0793ea6cf42755b68eb761dc7bf9da3eef52f28f950b15b01d81cc418c6dfb741829e9fb382812e136e312308bab569589401efbf8845a5";

        Assert.assertTrue(encryptedDataHex.equalsIgnoreCase(encryptedDataOnVector));


    }

}