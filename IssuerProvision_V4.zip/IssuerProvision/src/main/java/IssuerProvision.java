import org.bouncycastle.util.encoders.Base64;
import org.bouncycastle.util.encoders.Hex;

import java.io.ByteArrayInputStream;
import java.security.KeyPair;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;

/**
 * Created by liliang on 7/18/16.
 * CopyRight Apple Inc.
 * See LICENSE.txt for this sample’s licensing information
 */
public class IssuerProvision {

    public static final String APPLE_LEAF_CERT="MIIEDzCCA7WgAwIBAgIIWTFFmTO6SakwCgYIKoZIzj0EAwIwgYExOzA5BgNVBAMM\n" +
            "MlRlc3QgQXBwbGUgV29ybGR3aWRlIERldmVsb3BlcnMgUmVsYXRpb25zIENBIC0g\n" +
            "RUNDMSAwHgYDVQQLDBdDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTETMBEGA1UECgwK\n" +
            "QXBwbGUgSW5jLjELMAkGA1UEBhMCVVMwHhcNMTUwNDIxMTY0ODMzWhcNMTcwNTIw\n" +
            "MTY0ODMzWjBtMTYwNAYDVQQDDC1lY2MtY3J5cHRvLXNlcnZpY2VzLWVuY2lwaGVy\n" +
            "bWVudF9VQzYtTk9OLVBST0QxETAPBgNVBAsMCEFwcGxlUGF5MRMwEQYDVQQKDApB\n" +
            "cHBsZSBJbmMuMQswCQYDVQQGEwJVUzBZMBMGByqGSM49AgEGCCqGSM49AwEHA0IA\n" +
            "BGXYAm+04Y15uQt4bcy9WqM6yhV0PfqnaIV4EFC3F5DiMEReemvC/8muQbQBm/il\n" +
            "wpgxzDwwu8IzZKuRGPrHc76jggIoMIICJDBPBggrBgEFBQcBAQRDMEEwPwYIKwYB\n" +
            "BQUHMAGGM2h0dHA6Ly9vY3NwLXVhdC5jb3JwLmFwcGxlLmNvbS9vY3NwMDQtdGVz\n" +
            "dHd3ZHJjYWVjYzAdBgNVHQ4EFgQUP76eZMEYRo+05h1JgZBqJNLL3xUwDAYDVR0T\n" +
            "AQH/BAIwADAfBgNVHSMEGDAWgBTW1tVa5f/9wnw0w0PevWh2XDapvjCCAR0GA1Ud\n" +
            "IASCARQwggEQMIIBDAYJKoZIhvdjZAUBMIH+MIHDBggrBgEFBQcCAjCBtgyBs1Jl\n" +
            "bGlhbmNlIG9uIHRoaXMgY2VydGlmaWNhdGUgYnkgYW55IHBhcnR5IGFzc3VtZXMg\n" +
            "YWNjZXB0YW5jZSBvZiB0aGUgdGhlbiBhcHBsaWNhYmxlIHN0YW5kYXJkIHRlcm1z\n" +
            "IGFuZCBjb25kaXRpb25zIG9mIHVzZSwgY2VydGlmaWNhdGUgcG9saWN5IGFuZCBj\n" +
            "ZXJ0aWZpY2F0aW9uIHByYWN0aWNlIHN0YXRlbWVudHMuMDYGCCsGAQUFBwIBFipo\n" +
            "dHRwOi8vd3d3LmFwcGxlLmNvbS9jZXJ0aWZpY2F0ZWF1dGhvcml0eS8wQQYDVR0f\n" +
            "BDowODA2oDSgMoYwaHR0cDovL2NybC11YXQuY29ycC5hcHBsZS5jb20vYXBwbGV3\n" +
            "d2RyY2FlY2MuY3JsMA4GA1UdDwEB/wQEAwIDKDAPBgkqhkiG92NkBicEAgUAMAoG\n" +
            "CCqGSM49BAMCA0gAMEUCIQDnTo2QIGmVq5bG9D2O05T1QVgZk2TYxe9gmiNRLz21\n" +
            "tgIgYABVOnnIPIMfwgPNH3bMZar+TO7saxwYD8cee6qQrdM=";



    public static final String AES_V2_ID = "id-aes256-GCM";
    public static final String PARTY_U="Apple";

    public static void main(String[] args){
        try {
            String msg="Data to encrypt";
            byte[] msgBytes=msg.getBytes("UTF-8");
            System.out.println("Message to encrypt in hex: "+Hex.toHexString(msgBytes));
            //step 4 generate a random EC key pair
            KeyPair keyPair= CryptoUtils.generateECDHKeyPair();

            byte[] encryptedData=encryptData(msgBytes,(ECPublicKey) keyPair.getPublic(),(ECPrivateKey)keyPair.getPrivate());

            System.out.println("Encrypted data in hex: "+Hex.toHexString(encryptedData));

        }catch (Exception e){
            e.printStackTrace();
        }


    }

    public static byte[] encryptData(byte[] data, ECPublicKey publicKey, ECPrivateKey privateKey) throws Exception{

        //step 1 get certificate from Apple's server certificate file
        X509Certificate leaf = getAppleCertFromBase64String();

        //step 2 get Apple static public key
        ECPublicKey appleServerKey=(ECPublicKey) leaf.getPublicKey();
        String uncompressedAppleServerKey= CryptoUtils.ecPublicKey2HexPrefix04(appleServerKey);
        System.out.println("Apple static public key: "+uncompressedAppleServerKey);

        //step 3 get Apple static public key hash
        byte[] keyEncodedBytes = appleServerKey.getEncoded();
        byte[] keyHashBytes= CryptoUtils.doSHA256(keyEncodedBytes);
        System.out.println("Apple server public key hash in hex: "+ Hex.toHexString(keyHashBytes));


        //step 4 generate shared secret using ephemeral private key + static apple public key
        byte[] sharedSecret = CryptoUtils.generateSharedSecret(appleServerKey, privateKey);
        String sharedSecretHex=Hex.toHexString(sharedSecret);  //Z in the spec
        System.out.println("Shared Secret in hex: "+sharedSecretHex);

        //Step 5 get ephemeral public key in uncompressed format (partyV in spec)
        String uncompressedEphemeralKeyHex= CryptoUtils.ecPublicKey2HexPrefix04(publicKey);

        String counterHex="00000001";

        String algorithmIdHex= Hex.toHexString(AES_V2_ID.getBytes("UTF-8"));
        String partyUHex = Hex.toHexString(PARTY_U.getBytes("UTF-8")); //partyU info

        //calculate the length of the algorithm id in bytes
        String algorithmIdLengthHex = Integer.toHexString(AES_V2_ID.getBytes("UTF-8").length);

        //pad 0 to make a valid Hex string
        if (1 == algorithmIdLengthHex.length() % 2) {
            algorithmIdLengthHex = "0" + algorithmIdLengthHex;
        }

        //since algorithm id is treated as a varying-length string. it should be preceded by its length.
        String otherInfoHex=algorithmIdLengthHex+algorithmIdHex+partyUHex+uncompressedEphemeralKeyHex;

        //Step 6 KDF
        String hashInput=counterHex+sharedSecretHex+otherInfoHex;
        System.out.println("Hash input into KDF: "+hashInput);

        byte[] hashInputBytes = Hex.decode(hashInput);
        byte[] sharedKeyBytes = CryptoUtils.doSHA256(hashInputBytes);

        byte[] aesKey = new byte[32];
        System.arraycopy(sharedKeyBytes, 0, aesKey, 0, aesKey.length);

        System.out.println("ASE key in hex: "+Hex.toHexString(aesKey));
        byte[] iv = new byte[12];
        byte[] encryptedData = CryptoUtils.doAESGCMEncrypt(aesKey, data, iv);

        System.out.println("Encrypted data in hex: "+Hex.toHexString(encryptedData));

        return encryptedData;

    }
    public static X509Certificate getAppleCertFromBase64String() throws Exception{
        byte [] certificateBytes = Base64.decode(APPLE_LEAF_CERT.getBytes() );
        CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
        return  (X509Certificate)certificateFactory.generateCertificate( new ByteArrayInputStream( certificateBytes ) );
    }

}
