
import org.apache.log4j.Logger;
import org.bouncycastle.jce.ECNamedCurveTable;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.spec.ECNamedCurveParameterSpec;
import org.bouncycastle.jce.spec.ECNamedCurveSpec;

import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.math.BigInteger;
import java.security.*;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.*;


/**
 * ECC Crypto utilities based on P-256 curve
 * Created by liliang on 7/18/2016. CopyRight Apple Inc.
 * See LICENSE.txt for this sample’s licensing information
 */
public class CryptoUtils {
    private static final Logger LOGGER = Logger.getLogger(CryptoUtils.class);

    public static final String DEFAULT_PROVIDER = "BC";

    private static final String  NAMED_CURVE           = "P-256";
    private static final ECNamedCurveParameterSpec EC_NAMED_CURVE_PARAMETER_SPEC  = ECNamedCurveTable.getParameterSpec( NAMED_CURVE );
    private static final ECNamedCurveSpec EC_NAMED_CURVE_SPEC   = new ECNamedCurveSpec(EC_NAMED_CURVE_PARAMETER_SPEC .getName(), EC_NAMED_CURVE_PARAMETER_SPEC.getCurve(), EC_NAMED_CURVE_PARAMETER_SPEC.getG(), EC_NAMED_CURVE_PARAMETER_SPEC.getN());


    static {
        try {
            Security.addProvider(new BouncyCastleProvider());
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(e);
        }
    }



    public static KeyPair generateECDHKeyPair() throws InvalidAlgorithmParameterException,
            NoSuchProviderException, NoSuchAlgorithmException {
        return generateECDHKeyPair(DEFAULT_PROVIDER);
    }

    public static KeyPair generateECDHKeyPair(String provider)
            throws InvalidAlgorithmParameterException, NoSuchProviderException, NoSuchAlgorithmException {
        KeyPairGenerator keyPairECDHCGenerator;
        keyPairECDHCGenerator = KeyPairGenerator.getInstance("ECDH", provider);
        keyPairECDHCGenerator.initialize(EC_NAMED_CURVE_SPEC, new SecureRandom());
        return keyPairECDHCGenerator.generateKeyPair();
    }


    public static ECPublicKey hex2ECDHPublicKey(String hexX, String hexY)
            throws InvalidKeySpecException, NoSuchProviderException, NoSuchAlgorithmException {
        return hex2ECDHPublicKey(hexX, hexY, DEFAULT_PROVIDER);
    }

    public static ECPublicKey hex2ECDHPublicKey(String hexX, String hexY, String provider)
            throws InvalidKeySpecException, NoSuchProviderException, NoSuchAlgorithmException {
        ECPublicKeySpec ecPublicKeySpec =
                new ECPublicKeySpec(new ECPoint(new BigInteger(hexX, 16), new BigInteger(hexY, 16)),
                        EC_NAMED_CURVE_SPEC);
        KeyFactory factoryECDHC = KeyFactory.getInstance("ECDH", provider);
        return (ECPublicKey) factoryECDHC.generatePublic(ecPublicKeySpec);
    }


    public static ECPrivateKey hexToECDHCPrivateKey(String eccPvtD) throws InvalidKeySpecException,
            NoSuchProviderException, NoSuchAlgorithmException {
        return hexToECDHCPrivateKey(eccPvtD, DEFAULT_PROVIDER);
    }

    public static ECPrivateKey hexToECDHCPrivateKey(String eccPvtD, String provider)
            throws InvalidKeySpecException, NoSuchProviderException, NoSuchAlgorithmException {
        KeyFactory factoryECDHC = KeyFactory.getInstance("ECDH", provider);
        ECPrivateKeySpec ecPrivateKeySpec =
                new ECPrivateKeySpec(new BigInteger(eccPvtD, 16), EC_NAMED_CURVE_SPEC);
        return (ECPrivateKey) factoryECDHC.generatePrivate(ecPrivateKeySpec);
    }

    public static byte[] generateSharedSecret(ECPublicKey ecPublicKey, PrivateKey ephemeralPvt)
            throws InvalidKeySpecException, InvalidKeyException, NoSuchProviderException,
            NoSuchAlgorithmException {
        return generateSharedSecret(ecPublicKey, ephemeralPvt, DEFAULT_PROVIDER);
    }

    public static byte[] generateSharedSecret(ECPublicKey ecPublicKey, PrivateKey ephemeralPvt,
                                              String provider) throws InvalidKeySpecException, InvalidKeyException,
            NoSuchProviderException, NoSuchAlgorithmException {
        KeyAgreement agreement = KeyAgreement.getInstance("ECDH", provider);
        agreement.init(ephemeralPvt);
        agreement.doPhase(ecPublicKey, true);
        return agreement.generateSecret();
    }

    public static byte[] doSHA256(byte[] msg) throws NoSuchProviderException,
            NoSuchAlgorithmException {
        return doSHA256(msg, DEFAULT_PROVIDER);
    }

    public static byte[] doSHA256(byte[] msg, String provider) throws NoSuchProviderException,
            NoSuchAlgorithmException {
        MessageDigest hash = MessageDigest.getInstance("SHA256", provider);
        return hash.digest(msg);
    }

    public static byte[] doAESGCMEncrypt(byte[] keyBytes, byte[] msg, byte[] ivBytes)
            throws InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException,
            IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException,
            NoSuchProviderException {
        return doAESGCMEncrypt(keyBytes, msg, ivBytes, DEFAULT_PROVIDER);
    }

    public static byte[] doAESGCMEncrypt(byte[] keyBytes, byte[] msg, byte[] ivBytes, String provider)
            throws InvalidAlgorithmParameterException, InvalidKeyException, BadPaddingException,
            IllegalBlockSizeException, NoSuchPaddingException, NoSuchAlgorithmException,
            NoSuchProviderException {
        SecretKeySpec key = new SecretKeySpec(keyBytes, "AES");
        IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
        Cipher aesCipher = Cipher.getInstance("AES/GCM/NoPadding", provider);
        aesCipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
        return aesCipher.doFinal(msg);
    }

    public static String ecPublicKey2HexPrefix04(ECPublicKey ecPublicKey){
        ECPoint w = ecPublicKey.getW();
        String x= padKeyTo256Bits(w.getAffineX().toString(16));
        String y= padKeyTo256Bits(w.getAffineY().toString(16));

        return "04" + x + y;
    }


    public static String padKeyTo256Bits(String keyHex){
        String ret=keyHex;
        if (64>keyHex.length()){
            for (int i=0;i<64-keyHex.length();i++){
                ret="0"+ret;
            }
        }
        return ret;
    }

}
